# Sprenses · Otel Yönetimi — Tasarımlar

Bu klasör tüm tasarımların **son hâlini** içerir (Temmuz 2026). Commit için hazırdır.

## İçerik

**Masaüstü**
- `Panel Yeniden Tasarım.dc.html` — genel yönetim paneli (KPI, T hesap cetveli, nakit koruma, onay kutusu)
- `Cariler Yeniden Tasarım.dc.html` — tedarikçi cari modülü: liste + ekstre + notlar (ekle/düzenle/sil/tik) + firma bilgileri (iletişim & IBAN)
- `Acente Mahsup & Nakit Akım.dc.html` — birleşik modül: rezervasyon + alınan avanslar + satış faturaları + nakit akım. Avans mahsubu, acenteye göre vadeli tahsilat, €11M yıl sonu ciro hedefi (mevcut rezervasyon + ek tahmin) ve runway projeksiyonu
- `Nakit Akım Yeniden Tasarım.dc.html` — dönemsel giriş/çıkış T cetveli
- `Nakit Koruma.dc.html` — ödeme erteleme + canlı runway projeksiyonu
- `Otel Rezervasyon Yeniden Tasarım.dc.html` — rezervasyon yönetimi

**Mobil**
- `Panel Mobil.dc.html`
- `Otel Rezervasyon Mobil.dc.html`

**Runtime / bağımlılıklar**
- `support.js` — Design Component runtime (tüm `.dc.html` dosyaları buna bağlı)
- `ios-frame.jsx` — mobil prototiplerin iOS çerçevesi
- `index.html` — tüm tasarımlara bağlantı veren giriş sayfası

## Çalıştırma

`.dc.html` dosyaları tarayıcıda doğrudan `support.js` ile açılır. En sağlıklısı klasörü basit bir sunucuyla servis etmek:

```
python3 -m http.server
```

Ardından tarayıcıda `index.html` açılır.
