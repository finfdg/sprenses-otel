# Handoff: Sprenses Otel — Panel (Dashboard) Yeniden Tasarımı

## Genel Bakış
Bu paket, `finfdg/sprenses-otel` projesinin **Panel** ekranının (`frontend/src/routes/dashboard/+page.svelte`) yeniden tasarımını içerir. Yeni panel; finans KPI kartları, **T Hesap Cetveli mantığında interaktif bir Nakit Akım modülü** (Günlük/Haftalık/Aylık/Yıllık sekmeleri + tarih gezgini + açılır hesap grupları), son hareketler listesi ve alta yerleştirilmiş **Bekleyen Onay** kartı (tıklayınca Onay Kutusu modalı) içerir. Hem masaüstü hem mobil düzen tasarlanmıştır.

## Tasarım Dosyaları Hakkında
Bu klasördeki `*.dc.html` dosyaları **HTML ile hazırlanmış tasarım referanslarıdır** — istenen görünüm ve davranışı gösteren prototiplerdir, doğrudan kopyalanacak üretim kodu değildir. Görev, bu tasarımları projenin **mevcut ortamında yeniden inşa etmektir**: SvelteKit + Svelte 5 (runes) + Tailwind CSS, ve `frontend/src/lib/components` altındaki mevcut bileşenler (`StatCard.svelte`, `Sidebar.svelte`, `Topbar.svelte`, `Modal.svelte`, `SegmentedControl.svelte` vb.). Bu README tek başına yeterlidir; prototipleri açamasanız bile buradan uygulayabilirsiniz.

> **.dc.html dosyalarını açmak isterseniz:** bunlar bir "Design Component" runtime'ı (`support.js`) kullanır; `python3 -m http.server` gibi basit bir sunucuyla klasörü servis edip tarayıcıda açın. Mobil dosya ayrıca `ios-frame.jsx` (React) bileşenini iPhone çerçevesi için yükler.

## Fidelity
**High-fidelity (hifi).** Renkler, tipografi, boşluklar ve etkileşimler nihaidir. Aşağıdaki değerleri birebir kullanın. Not: prototip **yeni bir lacivert/altın + serif görsel dil** kullanır; mevcut uygulama **teal (Tailwind)** temalıdır. Uygulamadan önce "Tema Kararı" bölümüne bakın.

## Ekran Görüntüleri (`screenshots/`)
- `01-masaustu-panel.png` — masaüstü panel genel görünüm (sidebar + KPI 3×2 + Nakit Akım T hesap başlangıcı).
- `02-masaustu-onay-modal.png` — Bekleyen Onay kartına tıklayınca açılan Onay Kutusu modalı.
- `03-mobil-panel.png` — mobil panel (üst bar + KPI 2×3 + Nakit Akım özet kartı).
- `04-mobil-t-hesap.png` — mobil Nakit Akım özet kartı açıldığında görünen tam T hesap cetveli (sekmeler + tarih gezgini + dikey Giriş/Çıkış).

---

## Tema Kararı (uygulamadan önce netleştirin)
İki seçenek var:
1. **Sadece işlevsel/yapısal değişiklikler** — mevcut teal temayı koruyun; yalnızca yeni bileşen yapısını (T hesap Nakit Akım, KPI seti, Bekleyen Onay kartı+modal) ekleyin. Renkleri mevcut Tailwind teal paletiyle eşleyin (aşağıdaki renk rollerini teal karşılıklarıyla değiştirin).
2. **Komple yeniden temalama** — panelin tamamını bu paketteki lacivert/altın + Spectral/IBM Plex diline geçirin. Bu, en azından Panel rotası kapsamında yeni renk sınıfları/token'lar gerektirir; global `app.css`/Sidebar/Topbar tonlarını da etkileyebilir.

Aşağıdaki spesifikasyon **hifi (lacivert/altın)** değerleriyle yazılmıştır. Seçenek 1 seçilirse renk rollerini teal eşlerine çevirin, yapı/etkileşim aynı kalır.

---

## Design Tokens

### Renkler
| Rol | Hex |
|---|---|
| Birincil lacivert (sidebar, koyu kartlar, T-account çizgileri) | `#1b2b45` |
| Lacivert – aktif/ikincil | `#2c4269` |
| Lacivert üzeri metin / muted | `#e8ecf3` / `#c3cde0` / `#8496b3` / `#9fb0cb` |
| Kanvas (sayfa zemini) | `#f4f0e7` |
| Kart zemini | `#fffdf7` |
| Kart kenarlığı | `#e9e0cd` (topbar/sidebar ayraç `#e7dfcd`) |
| Ana metin (ink) | `#232733` |
| İkincil metin / muted | `#8a8574` / `#a09a88` |
| Pirinç/altın aksan | `#bd9a45` |
| Altın – yumuşak zemin (rozet/çip) | `#f4ecd4` |
| Altın – koyu metin | `#8a6f22` |
| Altın – değer (koyu kart üzeri) | `#e8c979` |
| Grafik/T-account: Giriş | `#2c4269` · Çıkış | `#d8bd76` |
| Pozitif (yeşil) | `#5a8f6e` (açık zemin) · `#3f8f68` (özet) · `#8fd0a8` (koyu zemin) |
| Negatif / borç (Cariler değeri) | `#b5533a` · net negatif `#c0533a` / `#e79b8a` |
| Modal arka plan karartma | `rgba(20,25,40,.45)` |

### Tipografi (Google Fonts)
- **Spectral** (serif) — başlıklar, logo, kart başlıkları. Ağırlık 600.
- **IBM Plex Sans** — gövde/etiket metni.
- **IBM Plex Mono** — tüm para tutarları ve sayısal değerler.
- Boyutlar: karşılama 19px/Spectral · KPI değeri 22px/Mono · KPI etiketi 10px uppercase (letter-spacing .5px) · kart başlığı 16–17px/Spectral · T-account satır 13px · tutarlar 12.5–13px/Mono.

### Yarıçap & gölge
- Kartlar: `border-radius: 16px` (büyük), `12px` (KPI), `18px` (modal panel).
- Modal gölge: `0 24px 60px rgba(0,0,0,.32)`.

---

## Ekranlar

### 1) Masaüstü Panel (`Panel Yeniden Tasarım.dc.html`)
Düzen: solda sabit **Sidebar (240px)**, sağda dikey akış: **Topbar (66px)** + kaydırılabilir içerik (`padding: 24px 30px`, `gap: 20px`).

**Sidebar** (`#1b2b45`): üstte pirinç kare "S" logosu + "Sprenses" (Spectral) / "OTEL YÖNETİMİ" (10px, letter-spacing 2px). Nav: **Panel** (aktif, zemin `#2c4269`), **Yönetim Paneli**, **Mesajlaşma** (sağda altın rozet "3"), ayraç + "MODÜLLER" başlığı, **Finans** (sağda altın "6"), **Muhasebe**, **İnsan Kaynakları**, **Satış** (sağda altın nokta), **Stok**, **Kalite**. Alt: "Sprenses v1.0". (İkonlar mevcut repodaki Heroicons `d` path'leri — `$lib/config/navigation.ts`'teki ile aynı.)

**Topbar**: solda karşılama "Günaydın, Mert" (Spectral 19px) + "Cumartesi, 4 Temmuz 2026 · Finans Müdürü". Sağda: arama pill'i ("Ara…"), "7 çevrimiçi" (yeşil nokta), bildirim zili (altın nokta rozetli), avatar (lacivert daire "M").

**KPI ızgarası** — `grid-template-columns: repeat(3,1fr); gap:16px` (mobilde 2 sütun). 6 kart:
| Etiket | Değer | Alt bilgi | Not |
|---|---|---|---|
| Bankalar | €2,41M | +%4,2 bu ay (yeşil, ↑) | değer lacivert |
| Doluluk | %78 | 124 / 159 oda dolu | |
| Avanslar | €186K | €214K alındı · 3 bekleyen | |
| Cariler | €318K | 12 borçlu cari | **değer `#b5533a`** |
| Çekler | €142K | 3 bekleyen · 1 vadesi geçmiş | |
| Krediler | €1,24M | 4 ürün · kalan borç | |

Kart stili: zemin `#fffdf7`, kenar `#e9e0cd`, radius 12px, `padding:13px 15px`; etiket 10px uppercase muted; değer IBM Plex Mono 22px `#1b2b45`; alt bilgi 12px muted.

**Nakit Akım · T Hesap Cetveli** (aşağıda ayrı bölüm — ana etkileşimli modül).

**Son Hareketler**: tam genişlik kart; renkli nokta + metin satırları (banka ekstresi, rezervasyon, kalite formu, kredi vadesi).

**Bekleyen Onay (uzun kart, en altta)**: tam genişlik `#1b2b45` kart, `padding:20px 26px`, tıklanabilir. Sol: pirinç yuvarlak ikon (check-circle) + "BEKLEYEN ONAY" etiketi + Mono 28px altın "6" + "işlem onayınızı bekliyor". Orta: çipler (`3 Satış Faturası`, `2 Avans Talebi`, `1 Düzenli Ödeme`) — zemin `rgba(255,255,255,.08)`, kenar `rgba(255,255,255,.12)`, radius 20px. Sağ: altın "İncele →". Tıklayınca **Onay Kutusu modalı** açılır.

### 2) Mobil Panel (`Panel Mobil.dc.html`)
iPhone çerçevesi (referans için). Yapı:
- **Üst bar** (`#1b2b45`, sticky): hamburger, pirinç "S" + "Panel", bildirim (rozet), avatar. (Gerçek uygulamada mevcut `Sidebar.svelte`'in off-canvas mobil hali + `Topbar.svelte` kullanılır; hamburger onu açar.)
- **Karşılama** + **KPI 2 sütun** (aynı 6 kart, daha küçük: değer 18px, `padding:11px 13px`).
- **Nakit Akım — özet kart**: kapalıyken "Bugün" için üç mini kutu (Giriş €16.710 / Çıkış €3.660 / Net +€13.050) + "Detaylı T hesap cetveli için dokun ›". **Dokununca tam T-account görünümü açılır** (sağ üstte yukarı-ok ile kapanır). Bu daralt/genişlet davranışı mobile özeldir (`expanded` state).
- **Bekleyen Onay uzun kart** (Son Hareketler'in altında): masaüstündekiyle aynı, dokununca modal.
- **Onay Kutusu modalı**: ortada, arka plan karartma, × / dışına dokununca kapanır (masaüstüyle aynı).

---

## Ana Modül: Nakit Akım · T Hesap Cetveli
İnteraktif. Önerilen yeni bileşen: `$lib/components/CashFlowTAccount.svelte`.

**Başlık**: "Nakit Akım · T Hesap Cetveli" (Spectral 17px) + "Hesap hareketleri · EUR · başlığa tıklayarak detayı açın".

**Sekmeler** (segmented control): `Günlük`, `Haftalık`, `Aylık`, `Yıllık`. Aktif: lacivert pill, metin `#f4ecd4`. Varsayılan **Aylık**. (Mevcut `SegmentedControl.svelte` kullanılabilir.)

**Tarih gezgini**: `‹` — ortada dönem etiketi (Mono 14px) + altında dönem tipi (uppercase) — `›`. Oklar dönemi bir birim ileri/geri alır. **İleri ok, offset 0'da (şimdiki dönem) devre dışı** (opacity .4). Etiketler:
- Günlük → "Cumartesi, 4 Temmuz 2026" (haftagünü + gün + ay + yıl)
- Haftalık → "29 Haz – 5 Tem 2026" (Pazartesi–Pazar aralığı)
- Aylık → "Temmuz 2026"
- Yıllık → "2026"
Referans tarih: **4 Temmuz 2026 (Cumartesi)**.

**T-account gövdesi**: üstte 2px lacivert yatay çizgi; iki eşit sütun ortada 2px lacivert dikey ayraçla ayrılır.
- Sol sütun başlığı: **Giriş** (aksan `#2c4269`) + sağda o dönemin toplamı (Mono, `#2c4269`).
- Sağ sütun başlığı: **Çıkış** (aksan `#bd9a45`) + toplam (Mono, `#8a6f22`).
- Her sütun, **açılır grup başlıklarından** oluşur. Grup satırı bir `button`: sol ok `▸` (kapalı) / `▾` (açık), grup adı (13px 600), "N işlem" (muted), grup toplamı (Mono). Tıklayınca altında kalem satırları açılır: `ad · tarih · tutar`.
- (Mobilde iki sütun yerine **dikey istif**: önce Giriş bölümü, sonra Çıkış bölümü.)

**Net satırı** (altta, lacivert bant): "Net Nakit Akım · {dönem etiketi}" + işaretli tutar (Mono 19px). Pozitif yeşil (`#8fd0a8` koyu zeminde), negatif `#e79b8a`.

### Veri modeli (mock — gerçek endpoint'e bağlanacak)
Her dönem için `giris[]` ve `cikis[]` grupları; her grup `{ label, items: [{ name, amount }] }`. Grup toplamı = kalem toplamı. Sütun toplamı = grup toplamları. Net = Giriş − Çıkış. **Tutarlar EUR**, `Intl.NumberFormat('tr-TR')` ile biçimlenir, `€` önekiyle.

Prototipteki tam mock veri (`Panel Yeniden Tasarım.dc.html` içindeki logic sınıfında `data = {…}`):
- **Aylık** — Giriş: Oda Gelirleri (Konaklama Deluxe&Suite 128.400 · Standart 84.200 · Grup&Acente 42.600), Yiyecek&İçecek (Restoran 38.200 · Bar&Lobby 15.400 · Oda servisi 8.600), Etkinlik&Toplantı (Toplantı salonu 21.000 · Düğün&Organizasyon 34.500), Diğer (Spa&Wellness 12.800 · Otopark&Transfer 5.400). Çıkış: Personel&Maaş (Maaş 96.500 · SGK 28.400 · Fazla mesai 6.200), Tedarikçi (Gıda 42.300 · Temizlik&Sarf 12.600 · Çamaşırhane 7.800), Sabit Giderler (Kira 34.000 · Elektrik&Doğalgaz 18.600 · Su&İnternet 4.200), Vergi&Finansman (KDV&Vergi 24.800 · Kredi taksiti 19.500). → Giriş €391.100, Çıkış €294.900, Net +€96.200.
- **Günlük / Haftalık / Yıllık** için benzer daha küçük/büyük setler `.dc.html`'de mevcuttur (Günlük net +€13.050; Yıllık net +€1.300.000). Farklı offset'lerde tutarlar prototipte bir çarpanla (`factor = max(0.5, 1 + offset*0.05 + 0.035*sin(offset*1.7))`) ölçeklenir — bu yalnızca "önceki/sonraki dönem" hissini vermek içindir; **gerçek uygulamada offset'e göre backend'den veri çekin.**

> **Backend notu:** Bu T-account gruplu görünümü besleyecek bir endpoint gerekir (dönem + offset parametreleriyle giriş/çıkış gruplarını ve kalemlerini döndüren). `docs/api-haritasi.md`'de mevcut Nakit Akım endpoint'i varsa genişletin; yoksa yeni bir `GET /finance/nakit-akim/t-hesap?period=&offset=` önerilir.

---

## Etkileşimler & State
Önerilen state (Svelte 5 runes — `$state`):
- `period: 'gunluk' | 'haftalik' | 'aylik' | 'yillik'` (varsayılan `'aylik'`).
- `offsets: { gunluk, haftalik, aylik, yillik }` — her dönem için dönem ofseti (0 = şimdiki; negatif = geçmiş). İleri, 0'da durur.
- `open: Record<string,boolean>` — hangi grupların açık olduğu (sekme değişince sıfırlanır).
- `onayOpen: boolean` — Onay Kutusu modalı.
- (Mobil) `expanded: boolean` — Nakit Akım özet kart / tam görünüm.

Davranışlar:
- Sekme tıklama → `period` değişir, `open` sıfırlanır.
- `‹`/`›` → ilgili dönemin ofseti −1/+1; `›` yalnızca offset < 0 iken çalışır (aksi halde devre dışı).
- Grup başlığı tıklama → o grubun `open` durumu toggle.
- Bekleyen Onay kartı tıklama → `onayOpen` toggle (modal aç/kapa).
- Modal: `×` veya arka plana (backdrop) tıklama kapatır; panel içine tıklama kapatmaz (`stopPropagation`).
- (Mobil) Nakit Akım özet kartına dokunma → `expanded = true`; tam görünümdeki yukarı-ok → `expanded = false`.

## Onay Kutusu Modalı
Öneri: mevcut `$lib/components/Modal.svelte` ile sarın. İçerik:
- Başlık "Onay Kutusu" (Spectral 17px) + "6 bekliyor" altın pill + kapat `×`.
- Satırlar (ikon kutusu + başlık + alt metin + tutar): "Satış Faturası #2024-1187 · Deniz Y. · şimdi · ₺84.200", "Avans Talebi · Elif K. · 18 dk · ₺12.000", "Düzenli Ödeme · Elektrik · Sistem · 1 sa · ₺6.480".
- Alt: "Tüm onayları gör →" (mevcut `/dashboard/finans/onay` sayfasına yönlendirebilir).

---

## Gerçek Verilere Bağlama (mevcut endpoint'ler)
`frontend/src/routes/dashboard/+page.svelte` zaten şu izinleri/endpoint'leri kullanıyor — KPI kartları bunlarla beslenmeli:
- Bankalar: `/finance/banks/accounts/` + `/finance/exchange-rates/latest` (EUR'ya çevrilmiş toplam).
- Çekler: `/finance/checks/summary`.
- Krediler: `/finance/krediler/summary/by-type`.
- Cariler: `/finance/cariler/vendors/summary`.
- Avanslar: `/finance/avanslar/summary`.
- Doluluk: rezervasyon/oda verisinden (Satış modülü) — uygun endpoint yoksa şimdilik statik bırakılabilir.
Nakit Akım T-account için yukarıdaki "Backend notu"na bakın.

## Kod Eşlemesi (nereye ne)
- `frontend/src/routes/dashboard/+page.svelte` — KPI kartlarını yeni set/düzene çevir; Nakit Akım grafiğini `CashFlowTAccount` ile değiştir; Son Hareketler + Bekleyen Onay uzun kartını ekle.
- Yeni: `frontend/src/lib/components/CashFlowTAccount.svelte` — sekmeler + tarih gezgini + T-account + açılır gruplar.
- Yeni: `frontend/src/lib/components/PendingApprovalsModal.svelte` (veya mevcut `Modal.svelte` içinde) — Onay Kutusu.
- Mevcut `StatCard.svelte` KPI kartları için kullanılabilir (accent prop'u lacivert/altın rollerine göre ayarlanır); `Sidebar.svelte`/`Topbar.svelte` tema kararına göre.

## Assets
Ek görsel/asset yok. İkonlar mevcut Heroicons path'leri (`$lib/config/navigation.ts`) ve prototipteki satır-içi SVG'lerle aynı. Fontlar Google Fonts: Spectral, IBM Plex Sans, IBM Plex Mono.

## Dosyalar
- `Panel Yeniden Tasarım.dc.html` — masaüstü panel prototipi (tüm etkileşim mantığı `<script data-dc-script>` içinde `class Component` olarak; T-account veri modeli, tarih hesaplama, toggle'lar + **Nakit Koruma / runway mantığı (`korumaVals`, `kOuts`, `kInflows`)** buradadır — birebir referans).
- `Panel Mobil.dc.html` — mobil panel prototipi (aynı mantık + özet kart daralt/genişlet).
- `Nakit Koruma.dc.html` — **Nakit Koruma / Ödeme Erteleme** modülünün bağımsız, tam interaktif referansı (tarih seçicili erteleme + canlı runway projeksiyonu).
- `support.js`, `ios-frame.jsx` — prototipleri tarayıcıda çalıştırmak için gereken runtime/çerçeve (yalnızca önizleme; üretim koduna kopyalanmaz).

---

## Modül: Nakit Koruma · Ödeme Erteleme (Runway)
Panelde Nakit Akım modülünün **hemen altında** yer alır; `Nakit Koruma.dc.html` bağımsız tam referanstır. Amaç: bankadaki nakit ile ay içindeki planlı hareketleri gün gün projekte edip **bakiyenin negatife düştüğü günü** göstermek ve kullanıcının bazı ödemeleri **belirli bir tarihe erteleyerek** bunu önlemesini sağlamak. Önerilen bileşen: `$lib/components/NakitKoruma.svelte`.

**Yapı:**
1. **Runway durum kartı** (lacivert): Bankadaki nakit + canlı **Durum** satırı (`⚠ 15 Temmuz'da bakiye negatife düşüyor` / `✓ Ay boyunca nakit pozitif kalıyor`), gün gün **projeksiyon eğrisi** (SVG polyline), sıfır bakiyeyi gösteren kırmızı kesikli çizgi, ve en düşük bakiye noktası (altın işaret) + `En düşük bakiye: 25 Tem · −€6.500`.
2. **Beklenen Tahsilatlar** — gelen nakit hareketleri çipler halinde (referans, ertelenemez).
3. **Bu Ay Planlı Ödemeler** — her satırda: tarih, ad, tutar, bir **`<input type="date">` erteleme tarihi seçici** (min = orijinal tarih) ve **↺ sıfırla** düğmesi. Tarih değiştirilince ödeme o güne taşınır; ay dışına (Temmuz sonrası) taşınırsa bu ayın projeksiyonundan çıkar (üstü çizili + `→ 5 Ağu tarihine ertelendi`). Eğri ve durum **canlı** güncellenir.
4. **Ay Sonu Projeksiyon Bakiyesi** bandı (canlı).

**State & hesap (Svelte 5 runes):**
- `dates: Record<paymentId, 'YYYY-MM-DD'>` — ertelenen ödemelerin yeni tarihi. Boşsa orijinal tarih geçerli.
- Projeksiyon: `bal = bankaBakiyesi`; gün 1→31 boyunca o güne düşen tahsilatlar eklenir, o güne düşen (etkin tarihine göre, ay içindeyse) ödemeler çıkarılır; `byDay[d]` kaydedilir. `firstNeg` = bakiyenin ilk negatif olduğu gün; `lowVal/lowDay` = en düşük bakiye. Ay dışına ertelenen ödeme projeksiyona **girmez**.
- Ertelenen ödeme borcu **silmez** — yalnızca zamanlamasını değiştirir; gerçek uygulamada ödemeye bir `deferred_to` (tarih) alanı yazılır ve runway hesabı bu tarihi dikkate alır.

**Gerçek veri:** planlı ödemeler = kredi taksitleri (vade), maaş günü, düzenli ödemeler, tedarikçi vadeleri, vergi son ödeme; tahsilatlar = beklenen çek tahsilatları, rezervasyon/acente tahsilatları. Banka bakiyesi mevcut `/finance/banks/accounts/` toplamından gelir. Erteleme işlemi ilgili kaydın vade/ödeme tarihini güncelleyen bir `PATCH` ile kalıcılaştırılır (yetki/onay akışına tabi olabilir).

> **Not (muhasebe):** Nakit Akım tablosunda avans/kredi **finansman**, kredi taksitinde **anapara** finansman-çıkış, **faiz+komisyon** faaliyet-gideridir (ana README'deki "Faaliyet / Finansman" ayrımına bakın). Runway hesabı ise türden bağımsız, **nakit** hareketin tamamını (anapara dahil) dikkate alır — çünkü bankadan gerçekte o tutar çıkar.
